<?php
{
	include('includes/dbcon.php');
	session_start();
	 $email=$_SESSION['email'];
    
   
    	$u="select * from user where email='$email'";
        $val=mysqli_query($con,$u);

 	    $row=mysqli_fetch_assoc($val);
		   
			
		print_r($row);
		$uid=$row['uid'];
		echo $uid;
		
	
}?>