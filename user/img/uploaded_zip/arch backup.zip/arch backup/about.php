<?php
    include('includes/subheader.php');
	
	
?>
<!-- About section -->
<section class="section-padding2">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-120 animate-box" data-animate-effect="fadeInUp">
                        <div class="about">
                            <figure>
                                <img src="img/about.jpg" alt="">
                            </figure>
                            <div class="caption">
                                <div class="section-number">.01</div>
                                <div class="section-subtitle">About us</div>
                                <div class="section-title">Our Firm Story</div>
                                <p>Architecture the inila duman aten elit finibus vivera alacus company design drudean seneice miuscibe noneten the fermen. The design architecture duiman finibus viverra nec a lacus drudeane sene voice fermen.</p>
                                <p>Design architecture duiman at elit finibus viverra nec a lacus vivento nuse ane sene voice the volume the miss drana inc fermen.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 animate-box" data-animate-effect="fadeInUp">
                        <div class="about left">
                            <figure>
                                <img src="img/project.jpg" alt="">
                            </figure>
                            <div class="caption">
                                <div class="section-number">.02</div>
                                <div class="section-subtitle">Our Story</div>
                                <div class="section-title">How we started</div>
                                <p>Architecture the inila duman aten elit finibus vivera alacus themone sen drudean seneice miuscibe noneten the fermen. The design architecture duiman finibus viverra nec a lacus drudeane sene voice fermen.</p>
                                <ul class="about-list">
                                    <li>
                                        <div class="icon">
                                            <span class="ti-check"></span>
                                        </div>
                                        <div class="text">
                                            <p>Architecture the inila duman aten fermen.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <span class="ti-check"></span>
                                        </div>
                                        <div class="text">
                                            <p>The design architecture duiman finibus.</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="icon">
                                            <span class="ti-check"></span>
                                        </div>
                                        <div class="text">
                                            <p>Placus udeane sene voice miss cuse aten.</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Team section -->
        <section class="team section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center mb-30">
                        <div class="section-number">.03</div>
                        <div class="section-subtitle">Our Experts</div>
                        <div class="section-title">Creative Team</div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="position-re o-hidden"> <img src="img/team/1.jpg" alt=""> </div>
                                <div class="con">
                                    <h5>Enrico Brown</h5>
                                    <p>dipl. Arch ETH/SIA</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="position-re o-hidden"> <img src="img/team/2.jpg" alt=""> </div>
                                <div class="con">
                                    <h5>Olivia White</h5>
                                    <p>dipl. Arch FH</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="position-re o-hidden"> <img src="img/team/3.jpg" alt=""> </div>
                                <div class="con">
                                    <h5>Daniel Martin</h5>
                                    <p>M.A. FH in Architecture</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<?php
   
   include('includes/footer.php');
   include('includes/scripts.php');
   
?>