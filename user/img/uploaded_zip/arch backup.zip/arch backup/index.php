<?php
    include('includes/header.php');
	
	
?>
	
 <!-- Content -->
 <div class="content-wrapper">
        <!-- Lines section -->
        <section class="content-lines-wrapper">
            <div class="content-lines-inner">
                <div class="content-lines"></div>
            </div>
        </section>
        <!-- About section -->
        <section class="about section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 animate-box" data-animate-effect="fadeInUp">
                        <div class="about">
                            <figure> <img src="img/about.jpg" alt=""> </figure>
                            <div class="caption">
                                <div class="section-number">.01</div>
                                <div class="section-subtitle">Get to know us</div>
                                <div class="section-title">About Company</div>
                                <p>Architecture the inila duman aten elit finibus vivera alacus company design drudean seneice miuscibe noneten the fermen. The design architecture duiman finibus viverra nec a lacus drudeane sene voice fermen.</p>
                                <p>Design architecture duiman at elit finibus viverra nec a lacus vivento nuse ane sene voice the volume the miss drana inc fermen.</p>
                                <div class="butn-dark"><a href="about.html"><span>Read more <i class="ti-arrow-right"></i></span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Services section -->
        <section class="services mb-90">
            <div class="container">
                <div class="row">
                    <!-- You can access the background images on the services style line in the style.css file. -->
                    <div class="col-md-12 animate-box" data-animate-effect="fadeInUp">
                        <div class="owl-carousel owl-theme">
                            <div class="item bg-1">
                                <div class="con">
                                    <div class="icon-img"><img src="img/icons/1.png" alt=""></div>
                                    <h5>Architectural Design</h5>
                                    <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                                </div>
                            </div>
                            <div class="item bg-2">
                                <div class="con">
                                    <div class="icon-img"><img src="img/icons/2.png" alt=""></div>
                                    <h5>Interior Design</h5>
                                    <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                                </div>
                            </div>
                            <div class="item bg-3">
                                <div class="con">
                                    <div class="icon-img"><img src="img/icons/3.png" alt=""></div>
                                    <h5>Exterior Design</h5>
                                    <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Projects section -->
        <section class="projects section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 mb-30">
                        <div class="section-number">.03</div>
                        <div class="section-subtitle">Portfolio</div>
                        <div class="section-title">Our Projects</div>
                    </div>
                </div>
                <div class="projects-carousel owl-theme owl-carousel">
                    <div class="projects-single">
                        <div class="projects-img"> <img src="img/projects/1.jpg" alt=""> </div>
                        <div class="projects-content">
                            <div class="projects-tagline">Exterior Design</div>
                            <div class="projects-title"><a href="project-page.html">Brown House, in New York</a></div>
                            <div class="projects-arrow"> <a href="project-page.html"><span class="ti-arrow-right"></span></a> </div>
                        </div>
                    </div>
                    <div class="projects-single">
                        <div class="projects-img"> <img src="img/projects/2.jpg" alt=""> </div>
                        <div class="projects-content">
                            <div class="projects-tagline">Interior Design</div>
                            <div class="projects-title"><a href="project-page.html">The Soft Villa, in Canada</a></div>
                            <div class="projects-arrow"> <a href="project-page.html"><span class="ti-arrow-right"></span></a> </div>
                        </div>
                    </div>
                    <div class="projects-single">
                        <div class="projects-img"> <img src="img/projects/3.jpg" alt=""> </div>
                        <div class="projects-content">
                            <div class="projects-tagline">Urban Design</div>
                            <div class="projects-title"><a href="project-page.html">Spacex Villa, in New York</a></div>
                            <div class="projects-arrow"> <a href="project-page.html"><span class="ti-arrow-right"></span></a> </div>
                        </div>
                    </div>
                    <div class="projects-single">
                        <div class="projects-img"> <img src="img/projects/4.jpg" alt=""> </div>
                        <div class="projects-content">
                            <p class="projects-tagline">Architecture</p>
                            <div class="projects-title"><a href="project-page.html">Box House, in London</a></div>
                            <div class="projects-arrow"> <a href="project-page.html"><span class="ti-arrow-right"></span></a> </div>
                        </div>
                    </div>
                    <div class="projects-single">
                        <div class="projects-img"> <img src="img/projects/5.jpg" alt=""> </div>
                        <div class="projects-content">
                            <div class="projects-tagline">Interior Design</div>
                            <div class="projects-title"><a href="project-page.html">Cotton House, in New York</a></div>
                            <div class="projects-arrow"> <a href="project-page.html"><span class="ti-arrow-right"></span></a> </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Video section -->
        <section class="section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 animate-box" data-animate-effect="fadeInUp">
                        <div class="project-video left">
                            <figure> <img src="img/project.jpg" alt="" class="img-fluid">
                                <div class="row">
                                    <div class="col-md-12 offset-md-4 valign v-middle clear">
                                        <div class="vid-area">
                                            <div class="vid-icon">
                                                <a class="play-button vid" href="https://youtu.be/y9j-BL5ocW8?t=12">
                                                    <svg class="circle-fill">
                                                        <circle cx="43" cy="43" r="39" stroke="#fff" stroke-width="1"></circle>
                                                    </svg>
                                                    <svg class="circle-track">
                                                        <circle cx="43" cy="43" r="39" stroke="none" stroke-width="1" fill="none"></circle>
                                                    </svg> <span class="polygon">
                                                        <i class="ti-control-play"></i>
                                                    </span> </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </figure>
                            <div class="caption">
                                <div class="section-number">.04</div>
                                <div class="section-subtitle">Take a look at our</div>
                                <div class="section-title">Recent Project</div>
                                <p>Take a look at our most recent project. Architecture the inila miss uman saten eliten finibus vivera alacus themone the drudean seneice muscibe noten tofermen. Design architecture duiman viverra nec a fermen.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Blog section -->
        
        <!-- Testimonials section -->
        
        <!-- Team section -->
        <section class="team section-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center mb-30">
                        <div class="section-number">.07</div>
                        <div class="section-subtitle">Our Experts</div>
                        <div class="section-title">Creative Team</div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="position-re o-hidden"> <img src="img/team/1.jpg" alt=""> </div>
                                <div class="con">
                                    <h5>Enrico Brown</h5>
                                    <p>dipl. Arch ETH/SIA</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="position-re o-hidden"> <img src="img/team/2.jpg" alt=""> </div>
                                <div class="con">
                                    <h5>Olivia White</h5>
                                    <p>dipl. Arch FH</p>
                                </div>
                            </div>
                            <div class="item">
                                <div class="position-re o-hidden"> <img src="img/team/3.jpg" alt=""> </div>
                                <div class="con">
                                    <h5>Daniel Martin</h5>
                                    <p>M.A. FH in Architecture</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
 <?php
   
	include('includes/footer.php');
	include('includes/scripts.php');
	
?>