<?php
    include('includes/subheader.php');
	
	
?>
<!-- Services section -->
<section class="services section-padding2">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center mb-30">
                        <div class="section-subtitle">What We Do</div>
                        <div class="section-title">Our Services</div>
                    </div>
                </div>
                <div class="row">
                    <!-- You can access the background images on the services style line in the style.css file. -->
                    <div class="col-md-4">
                        <div class="item bg-1">
                            <div class="con">
                                <div class="icon-img"><img src="img/icons/1.png" alt=""></div>
                                <h5>Architectural Design</h5>
                                <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item bg-2">
                            <div class="con">
                                <div class="icon-img"><img src="img/icons/2.png" alt=""></div>
                                <h5>Interior Design</h5>
                                <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item bg-3">
                            <div class="con">
                                <div class="icon-img"><img src="img/icons/3.png" alt=""></div>
                                <h5>Exterior Design</h5>
                                <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item bg-4">
                            <div class="con">
                                <div class="icon-img"><img src="img/icons/7.png" alt=""></div>
                                <h5>Decor Plan</h5>
                                <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item bg-5">
                            <div class="con">
                                <div class="icon-img"><img src="img/icons/5.png" alt=""></div>
                                <h5>3D Modelling</h5>
                                <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="item bg-6">
                            <div class="con">
                                <div class="icon-img"><img src="img/icons/6.png" alt=""></div>
                                <h5>Furniture Design</h5>
                                <p>Architecture bibendum eros onne vane the sutate the sit ame vehicula nubare alacera in evensa sitae zusto.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Positions -->
        <section class="positions section-padding2">
           <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center mb-30">
                        <div class="section-subtitle">Talent wanted</div>
                        <div class="section-title">Positions</div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-10 offset-md-1">
                        <div class="position"><a class="position-link" href="contact.html"></a>
                            <div class="position-category">Engineer</div>
                            <div class="position-title">Civil engineer</div>
                            <div class="position-time">Full-time</div>
                            <div class="position-icon"><i class="ti-arrow-top-right"></i></div>
                        </div>
                        <div class="position"><a class="position-link" href="contact.html"></a>
                            <div class="position-category">Engineer</div>
                            <div class="position-title">Construction engineer</div>
                            <div class="position-time">Full-time</div>
                            <div class="position-icon"><i class="ti-arrow-top-right"></i></div>
                        </div>
                        <div class="position"><a class="position-link" href="contact.html"></a>
                            <div class="position-category">Architect</div>
                            <div class="position-title">Interior Architect</div>
                            <div class="position-time">Full-time</div>
                            <div class="position-icon"><i class="ti-arrow-top-right"></i></div>
                        </div>
                        <div class="position"><a class="position-link" href="contact.html"></a>
                            <div class="position-category">Manager</div>
                            <div class="position-title">Project manager</div>
                            <div class="position-time">Full-time</div>
                            <div class="position-icon"><i class="ti-arrow-top-right"></i></div>
                        </div>
                    </div>
                </div>
           </div>
        </section>

