<?php
	$con=mysqli_connect("localhost","root","","id");
	session_start();

	session_destroy();
	header("location:/arch/index.php"); 
?>